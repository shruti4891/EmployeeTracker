package com.employee.selfcare.employeetracker.adapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import com.employee.selfcare.employeetracker.fragment.EmployeeLoginFragment;
import com.employee.selfcare.employeetracker.fragment.EmployeeSignupFragment;

/**
 * Created by Shruti Bansal
 */
public class EmployeeLogInSignUpAdapter extends FragmentStatePagerAdapter {

    public EmployeeLogInSignUpAdapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                return new EmployeeLoginFragment();
            case 1:
                return new EmployeeSignupFragment();

            default:
                return new EmployeeLoginFragment();
        }
    }

    @Override
    public int getCount() {
        return 2;
    }
}
