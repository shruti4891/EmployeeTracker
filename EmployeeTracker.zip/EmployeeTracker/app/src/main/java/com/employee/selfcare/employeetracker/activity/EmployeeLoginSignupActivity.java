package com.employee.selfcare.employeetracker.activity;

import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.employee.selfcare.employeetracker.R;
import com.employee.selfcare.employeetracker.adapter.EmployeeLogInSignUpAdapter;
import com.employee.selfcare.employeetracker.indicator.CirclePageIndicator;

/**
 * Created by Shruti Bansal
 */
public class EmployeeLoginSignupActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lyt_emp_signup);
        initGUI();
    }

    private void initGUI() {
        ViewPager mPagerSaleForcast = (ViewPager) findViewById(R.id.pager);
        PagerAdapter mPagerSaleForcastAdapter = new EmployeeLogInSignUpAdapter(getSupportFragmentManager());
        mPagerSaleForcast.setAdapter(mPagerSaleForcastAdapter);
        ((CirclePageIndicator) findViewById(R.id.circle_indicator_banner)).setViewPager(mPagerSaleForcast);
        int index = getIntent().getIntExtra("index", 0);
        mPagerSaleForcast.setCurrentItem(index);
        mPagerSaleForcast.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
            }

            @Override
            public void onPageSelected(int position) {
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
        findViewById(R.id.img_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
