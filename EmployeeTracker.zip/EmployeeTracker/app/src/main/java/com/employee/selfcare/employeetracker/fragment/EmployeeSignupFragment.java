package com.employee.selfcare.employeetracker.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.Fragment;
import android.util.DisplayMetrics;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.employee.selfcare.employeetracker.R;
import com.employee.selfcare.employeetracker.activity.EmployeeProfileActiviy;

/**
 * Created by Shruti Bansal
 */
public class EmployeeSignupFragment extends Fragment implements View.OnClickListener {

    EditText et_firstname, et_lastname, et_email;
    TextInputLayout tl_firstname, tl_lastname, tl_email;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(
                R.layout.lyt_fragment_signup, container, false);
        initGUI(rootView);
        return rootView;
    }

    private void initGUI(ViewGroup rootView) {
        rootView.findViewById(R.id.tv_fragment_signup).setOnClickListener(this);
        et_firstname = (EditText) rootView.findViewById(R.id.et_input_firstname);
        et_lastname = (EditText) rootView.findViewById(R.id.et_input_lastname);
        et_email = (EditText) rootView.findViewById(R.id.et_input_email);
        tl_firstname = (TextInputLayout) rootView.findViewById(R.id.tl_firstname);
        tl_lastname = (TextInputLayout) rootView.findViewById(R.id.tl_lastname);
        tl_email = (TextInputLayout) rootView.findViewById(R.id.tl_email);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_fragment_signup:
                validateSignUpData();
        }
    }

    private void validateSignUpData() {
        String strFirstName = et_firstname.getText().toString().trim();
        String strLastName = et_lastname.getText().toString().trim();
        String strEmail = et_email.getText().toString().trim();
        if (strFirstName == null || strFirstName.length() < 4 || strFirstName.equals("")) {
            tl_firstname.setErrorEnabled(true);
            tl_firstname.setError(getString(R.string.invalid_firstname));
        } else if (strLastName == null || strLastName.length() < 4 || strLastName.equals("")) {
            tl_lastname.setErrorEnabled(true);
            tl_lastname.setError(getString(R.string.invalid_lastname));
        } else if (strEmail.equals("") || strEmail == null || !Patterns.EMAIL_ADDRESS.matcher(strEmail).matches()) {
            tl_email.setErrorEnabled(true);
            tl_email.setError(getString(R.string.invalid_email));
        } else {
            tl_firstname.setErrorEnabled(false);
            tl_lastname.setErrorEnabled(false);
            tl_email.setErrorEnabled(false);
            tl_email.setHintAnimationEnabled(true);
            Toast.makeText(getActivity(), "signup done", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(getActivity(), EmployeeProfileActiviy.class);
            intent.putExtra("AccountExist", false);
            startActivity(intent);
        }
    }
}
