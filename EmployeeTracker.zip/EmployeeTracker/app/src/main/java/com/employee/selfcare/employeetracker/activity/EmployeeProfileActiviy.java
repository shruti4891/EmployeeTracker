package com.employee.selfcare.employeetracker.activity;

import android.app.AlertDialog.Builder;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.employee.selfcare.employeetracker.R;

/**
 * Created by Shruti Bansal
 */
public class EmployeeProfileActiviy extends AppCompatActivity implements View.OnClickListener {

    EditText ed_firstName, ed_lastName, ed_email, ed_address, ed_phone_number, ed_designation, ed_department, ed_income;
    String strFirstName, strLastName, strEmail, strAddress, strPhoneNum, strDesignation, strDepartment, strIncome;
    TextView btnupdate;
    SQLiteDatabase db;
    private Cursor c;
    boolean isAccountExist;
    private static final String SELECT_SQL = "SELECT * FROM employee";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_activity_user_profile_details);
        openDatabase();
        initGUI();
        isAccountExist = getIntent().getBooleanExtra("AccountExist", false);
        if (isAccountExist) {
            c = db.rawQuery(SELECT_SQL, null);
            c.moveToFirst();
            showRecords();
        }
    }

    private void initGUI() {
        findViewById(R.id.img_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        ed_firstName = (EditText) findViewById(R.id.ed_firstName);
        ed_lastName = (EditText) findViewById(R.id.ed_lastName);
        ed_email = (EditText) findViewById(R.id.ed_email);
        ed_address = (EditText) findViewById(R.id.ed_address);
        ed_phone_number = (EditText) findViewById(R.id.ed_phone_number);
        ed_designation = (EditText) findViewById(R.id.ed_designation);
        ed_department = (EditText) findViewById(R.id.ed_department);
        ed_income = (EditText) findViewById(R.id.ed_income);
        btnupdate = (TextView) findViewById(R.id.btn_done);
        btnupdate.setOnClickListener(this);

    }

    protected void openDatabase() {
        db = openOrCreateDatabase("EmployeeDB", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS employee(firstname VARCHAR, lastname VARCHAR, email VARCHAR, address VARCHAR, " +
                "phone VARCHAR, designation VARCHAR, department VARCHAR, income VARCHAR);");
    }

    protected void showRecords() {
        String firstName = c.getString(0);
        String latsname = c.getString(1);
        String email = c.getString(2);
        String address = c.getString(3);
        String phone = c.getString(4);
        String designation = c.getString(5);
        String dept = c.getString(6);
        String income = c.getString(7);


        ed_firstName.setText("" + firstName);
        ed_lastName.setText("" + latsname);
        ed_phone_number.setText("" + phone);
        ed_designation.setText("" + designation);
        ed_email.setText("" + email);
        ed_address.setText("" + address);
        ed_department.setText("" + dept);
        ed_income.setText("" + income);
    }

    public void showMessage(String title, String message) {
        Builder builder = new Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

    void insertIntoDB() {
        db.execSQL("INSERT INTO employee VALUES(" +

                "'" + ed_firstName.getText() + "'," +
                "'" + ed_lastName.getText() + "'," +
                "'" + ed_email.getText() + "'," +
                "'" + ed_address.getText() + "'," +
                "'" + ed_phone_number.getText() + "'," +
                "'" + ed_designation.getText() + "'," +
                "'" + ed_department.getText() + "'," +
                "'" + ed_income.getText() + "');");
    }

    @Override
    public void onClick(View v) {
        strFirstName = ed_firstName.getText().toString().trim();
        strLastName = ed_lastName.getText().toString().trim();
        strEmail = ed_email.getText().toString().trim();
        strAddress = ed_address.getText().toString().trim();
        strPhoneNum = ed_phone_number.getText().toString().trim();
        strDesignation = ed_designation.getText().toString().trim();
        strDepartment = ed_department.getText().toString().trim();
        strIncome = ed_income.getText().toString().trim();
        if (!isAccountExist) {
            validateField();
        }

//        insertIntoDB();
//        Toast.makeText(EmployeeProfileActiviy.this, "Record added", Toast.LENGTH_SHORT).show();

    }

    private void validateField() {
        if (!TextUtils.isEmpty(strFirstName) && !TextUtils.isEmpty(strLastName) && !TextUtils.isEmpty(strEmail)
                && !TextUtils.isEmpty(strAddress) && !TextUtils.isEmpty(strPhoneNum) && !TextUtils.isEmpty(strDesignation)
                && !TextUtils.isEmpty(strDepartment) && !TextUtils.isEmpty(strIncome)) {
            insertIntoDB();
            Toast.makeText(EmployeeProfileActiviy.this, "Record added", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(EmployeeProfileActiviy.this, "" + getString(R.string.enter_details), Toast.LENGTH_SHORT).show();
        }
    }
}
