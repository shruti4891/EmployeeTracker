package com.employee.selfcare.employeetracker.fragment;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.employee.selfcare.employeetracker.R;
import com.employee.selfcare.employeetracker.activity.EmployeeProfileActiviy;

/**
 * Created by Shruti Bansal
 */
public class EmployeeLoginFragment extends Fragment implements View.OnClickListener {

    EditText et_usernname, et_password;
    TextInputLayout tl_username, tl_password;
    SQLiteDatabase database;
    private Cursor cursor;
    private static final String SELECT_SQL = "SELECT * FROM employee";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(
                R.layout.lyt_fragment_login, container, false);
        initGUI(rootView);
        openDatabase();
        return rootView;
    }

    void insertIntoDB() {
        database.execSQL("CREATE TABLE IF NOT EXISTS employee(firstname VARCHAR, lastname VARCHAR, email VARCHAR, address VARCHAR, " +
                "phone VARCHAR, designation VARCHAR, department VARCHAR, income VARCHAR);");

        database.execSQL("INSERT INTO employee VALUES(" +
                "'" + "John" + "'," +
                "'" + "Doe" + "'" +
                ",'" + "john@gmail.com" + "'" +
                ",'" + "Ac-22b, down street, California" + "'" +
                ",'" + "441239495995" + "'" +
                ",'" + "HR" + "'" +
                ",'" + "Accounts" + "'" +
                ",'" + "40000" + "'" +
                ");");

        database.execSQL("INSERT INTO employee VALUES(" +
                "'" + "Christina" + "'," +
                "'" + "Aguilera" + "'" +
                ",'" + "chris@hotmail.com" + "'" +
                ",'" + "Ac-22b, up street, California" + "'" +
                ",'" + "441239495995" + "'" +
                ",'" + "Software Engineer" + "'" +
                ",'" + "Technology" + "'" +
                ",'" + "40000" + "'" +
                ");");

    }

    protected void openDatabase() {
        database = getActivity().openOrCreateDatabase("EmployeeDB", Context.MODE_PRIVATE, null);
        insertIntoDB();
        cursor = database.rawQuery(SELECT_SQL, null);
        cursor.moveToFirst();
    }

    private void initGUI(ViewGroup rootView) {
        rootView.findViewById(R.id.tv_fragment_login).setOnClickListener(this);
        et_usernname = (EditText) rootView.findViewById(R.id.et_input_username);
        et_password = (EditText) rootView.findViewById(R.id.et_input_password);
        tl_username = (TextInputLayout) rootView.findViewById(R.id.tl_input_username);
        tl_password = (TextInputLayout) rootView.findViewById(R.id.tl_input_password);
    }

    boolean checkIfDataExists(String name) {
        if (cursor != null) {
            String id = cursor.getString(0);
            if (id != null && (id.equalsIgnoreCase("John")) && id.equalsIgnoreCase(name)) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_fragment_login:
                validateLogInData();
        }
    }

    private void validateLogInData() {
        String strUsername = et_usernname.getText().toString().trim();
        String strPassword = et_password.getText().toString().trim();
        if (strUsername == null || strUsername.length() < 4 || strUsername.equals("")) {
            tl_username.setErrorEnabled(true);
            tl_username.setError(getString(R.string.invalid_name));
        } else if (strPassword == null || strPassword.length() < 4 || strPassword.equals("")) {
            tl_password.setErrorEnabled(true);
            tl_password.setError(getString(R.string.invalid_password));
        } else {
            if (checkIfDataExists(strUsername)) {
                tl_password.setErrorEnabled(false);
                tl_username.setErrorEnabled(false);
                tl_password.setHintAnimationEnabled(true);
                tl_username.setHintAnimationEnabled(true);
                Intent intent = new Intent(getActivity(), EmployeeProfileActiviy.class);
                intent.putExtra("AccountExist", true);
                startActivity(intent);
            } else {
                Toast.makeText(getActivity(), "Please enter Valid credentials & try again.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
