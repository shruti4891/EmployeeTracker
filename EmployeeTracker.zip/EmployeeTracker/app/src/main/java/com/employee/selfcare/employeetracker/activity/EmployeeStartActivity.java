package com.employee.selfcare.employeetracker.activity;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.employee.selfcare.employeetracker.R;

/**
 * Created by Shruti Bansal
 */
public class EmployeeStartActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.emp_login);
        initGUI();
    }

    private void initGUI() {
        TextView tv_title = (TextView) findViewById(R.id.tv_title);
        TextView tv_login = (TextView) findViewById(R.id.tv_login_);
        TextView tv_signup = (TextView) findViewById(R.id.tv_signup);
        TextView tv_or = (TextView) findViewById(R.id.tv_or);
        ImageView logIn = (ImageView) findViewById(R.id.iv_login);
        ImageView signUp = (ImageView) findViewById(R.id.iv_signup);

        // setting custom font
        Typeface customFont = Typeface.createFromAsset(getAssets(), "comicbd_0.ttf");
        tv_title.setTypeface(customFont);
        tv_login.setTypeface(customFont);
        tv_signup.setTypeface(customFont);
        tv_or.setTypeface(customFont);

        logIn.setOnClickListener(this);
        signUp.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.iv_login:
                Intent intent = new Intent(this, EmployeeLoginSignupActivity.class);
                intent.putExtra("index", 0);
                startActivity(intent);

                break;

            case R.id.iv_signup:
                intent = new Intent(this, EmployeeLoginSignupActivity.class);
                intent.putExtra("index", 1);
                startActivity(intent);
                break;

        }
    }
}
